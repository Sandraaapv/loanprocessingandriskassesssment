# Loan Approval and Risk Assessment System

## How to run
1. Install dependencies: `pip install -r requirements.txt`
2. Run the pipeline: `python3 loan_model.py`

## Files
- `loan_model.py` — full ML pipeline (data cleaning, training, evaluation, demo)
- `loan_train.csv` — dataset (491 loan applications)
- `loan_rf_model.joblib` — saved trained Random Forest model
- `feature_columns.joblib` — list of feature columns used (needed to reuse the model)
- `confusion_matrix.png`, `feature_importance.png`, `roc_curve.png` — result charts
- `results_summary.txt` — plain text summary of scores
- `PRESENTATION_GUIDE.md` — what to say during your demo tomorrow
