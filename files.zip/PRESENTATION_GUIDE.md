# Loan Approval and Risk Assessment System — Presentation Guide

## 1. What is this project? (say this first)
We built a system that predicts whether a bank should **approve or reject** a loan
application, based on the applicant's details (income, credit history, marital
status, etc). We used a **Random Forest** machine learning model.

## 2. What is a Random Forest? (in plain English)
- A single "Decision Tree" is like a flowchart of yes/no questions
  ("Is credit history good? → Is income above X? → Approve/Reject").
- One tree alone can make mistakes or be biased toward the data it saw.
- A **Random Forest** builds many different decision trees (we used 200),
  each trained on a random slice of the data, and then all trees **vote**.
- The majority vote becomes the final decision. This makes the model more
  accurate and less likely to overfit (memorize the training data instead of
  actually learning patterns).

## 3. Our Dataset
- 491 real loan applications with 12 attributes each: Gender, Married,
  Dependents, Education, Self-Employed, Applicant Income, Co-applicant Income,
  Loan Amount, Loan Term, Credit History, Property Area, and the outcome
  (Loan Approved / Rejected).
- Source: a public, commonly used loan-prediction dataset (same one used in
  many academic loan-approval projects).

## 4. Steps we followed (this is your "methodology" slide)
1. **Data Cleaning** — filled missing values (used median for numbers, most
   common value for categories), since some applicants had missing fields.
2. **Encoding** — converted text like "Male/Female" or "Yes/No" into numbers
   (0/1), because ML models only work with numbers.
3. **Train/Test Split** — split data into 80% for training the model, 20% for
   testing it on data it has never seen (392 train / 99 test).
4. **Model Training** — trained a Random Forest Classifier (200 trees).
5. **Evaluation** — measured how well it performs on the unseen test data.
6. **Feature Importance** — checked which factors matter most for approval.

## 5. Our Results (your key slide)
| Metric | Score | What it means |
|---|---|---|
| Accuracy | 81.8% | Out of 100 applications, ~82 predicted correctly |
| Precision | 84.9% | When model says "Approved", it's right ~85% of the time |
| Recall | 89.9% | Of all real approvals, model catches ~90% of them |
| F1 Score | 87.3% | Balance between precision & recall |
| ROC-AUC | 83.2% | How well the model separates good vs bad applicants (100% = perfect, 50% = random guessing) |

**Talking point:** "Our model performs significantly better than random
guessing (50%) and is in a solid range for a first version — 80%+ accuracy is
considered good for this classic dataset."

## 6. Most Important Factors (show `feature_importance.png`)
Ranked from most to least important:
1. **Credit History** — by far the biggest factor (makes sense — this is
   exactly what real banks care about most)
2. Applicant Income
3. Loan Amount
4. Co-applicant Income
5. Property Area, Dependents, Marital Status, etc. (smaller effects)

**Talking point:** "This matches real-world banking intuition — credit
history dominates the decision, which validates that our model learned
meaningful patterns instead of noise."

## 7. Live Demo (do this in front of the class)
Run in terminal:
```
python3 loan_model.py
```
It will print every step live: data loading → cleaning → training →
evaluation → a sample prediction at the end showing a real applicant and
whether the model approves them, with a confidence percentage.

You can also point to the 3 saved charts:
- `confusion_matrix.png` — shows correct vs incorrect predictions
- `feature_importance.png` — shows what drives approval decisions
- `roc_curve.png` — shows overall model quality

## 8. What's left for the final submission (mention as "next steps")
- Hyperparameter tuning (GridSearchCV) to push accuracy higher
- Try comparing with other models (Logistic Regression, XGBoost) to justify
  why Random Forest was chosen
- Build a simple web form (Streamlit) so a user can type in applicant details
  and get a live prediction
- Add a "risk score" (probability output) instead of just approve/reject, for
  a more nuanced risk assessment

## 9. Anticipated Questions & Answers
**Q: Why Random Forest and not another algorithm?**
A: It handles both numeric and categorical data well, resists overfitting
better than a single decision tree, and gives us feature importance for free
— useful for explaining *why* a loan was rejected, which matters for
transparency in finance.

**Q: How do you know the model isn't just memorizing?**
A: We tested it on 99 applications it never saw during training (the test
set), and it still got ~82% right.

**Q: What does "class_weight=balanced" mean in your code?**
A: Our dataset has more approvals than rejections. This setting tells the
model to pay equal attention to both classes instead of being biased toward
predicting "approved" all the time.
