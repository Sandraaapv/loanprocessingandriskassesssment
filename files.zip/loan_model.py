"""
Loan Approval and Risk Assessment System
Model: Random Forest Classifier

This script:
1. Loads the loan applicant dataset
2. Cleans and prepares the data (handles missing values, encodes text -> numbers)
3. Trains a Random Forest model to predict loan approval
4. Evaluates how good the model is
5. Shows which factors matter most for approval (feature importance)
6. Saves the trained model + charts for the demo
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")  # save charts as image files instead of popping up windows
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score, roc_curve
)

RANDOM_STATE = 42  # fixed seed so results are reproducible every time you run this

# -------------------------------------------------------------------
# STEP 1: LOAD THE DATA
# -------------------------------------------------------------------
df = pd.read_csv("loan_train.csv")
df = df.drop(columns=["Unnamed: 0", "Loan_ID"])  # Loan_ID is just an identifier, not useful for prediction

print("=" * 60)
print("STEP 1: DATA LOADED")
print("=" * 60)
print(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")
print(f"\nColumns: {list(df.columns)}")
print(f"\nMissing values per column:\n{df.isnull().sum()}")

# -------------------------------------------------------------------
# STEP 2: CLEAN THE DATA
# -------------------------------------------------------------------
# Fill missing numeric values with the median (middle value) of that column
for col in ["ApplicantIncome", "CoapplicantIncome", "LoanAmount", "Loan_Amount_Term", "Credit_History"]:
    df[col] = df[col].fillna(df[col].median())

# Fill missing categorical (text) values with the most common value in that column
for col in ["Gender", "Married", "Dependents", "Self_Employed"]:
    df[col] = df[col].fillna(df[col].mode()[0])

# "Dependents" has a value "3+" -> convert to a clean number 3
df["Dependents"] = df["Dependents"].replace("3+", 3).astype(int)

# Convert Yes/No, Male/Female, etc. (text) into numbers, because ML models only understand numbers
df["Gender"] = df["Gender"].map({"Male": 1, "Female": 0})
df["Married"] = df["Married"].map({"Yes": 1, "No": 0})
df["Education"] = df["Education"].map({"Graduate": 1, "Not Graduate": 0})
df["Self_Employed"] = df["Self_Employed"].map({"Yes": 1, "No": 0})
# Property_Area has 3 categories -> one-hot encode (creates separate 0/1 columns for each)
df = pd.get_dummies(df, columns=["Property_Area"], drop_first=True)

print("\n" + "=" * 60)
print("STEP 2: DATA CLEANED")
print("=" * 60)
print("No missing values remaining:", df.isnull().sum().sum() == 0)
print(f"\nFinal features used by the model: {[c for c in df.columns if c != 'Loan_Status']}")

# -------------------------------------------------------------------
# STEP 3: SPLIT INTO FEATURES (X) AND TARGET (y), THEN TRAIN/TEST SPLIT
# -------------------------------------------------------------------
X = df.drop(columns=["Loan_Status"])
y = df["Loan_Status"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
)

print("\n" + "=" * 60)
print("STEP 3: TRAIN/TEST SPLIT")
print("=" * 60)
print(f"Training samples: {len(X_train)}  |  Testing samples: {len(X_test)}")
print("(Model learns from the training set, then we test it on data it has never seen)")

# -------------------------------------------------------------------
# STEP 4: TRAIN THE RANDOM FOREST MODEL
# -------------------------------------------------------------------
# A Random Forest builds many decision trees on random subsets of data/features,
# then lets them "vote" -> reduces overfitting compared to a single decision tree.
model = RandomForestClassifier(
    n_estimators=200,     # number of trees in the forest
    max_depth=6,           # limits tree depth to avoid overfitting
    min_samples_leaf=4,
    random_state=RANDOM_STATE,
    class_weight="balanced"  # handles the fact that approvals > rejections in this data
)
model.fit(X_train, y_train)

print("\n" + "=" * 60)
print("STEP 4: MODEL TRAINED")
print("=" * 60)
print(f"Random Forest with {model.n_estimators} decision trees trained successfully.")

# -------------------------------------------------------------------
# STEP 5: EVALUATE THE MODEL
# -------------------------------------------------------------------
y_pred = model.predict(X_test)
y_proba = model.predict_proba(X_test)[:, 1]

accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_proba)

print("\n" + "=" * 60)
print("STEP 5: MODEL EVALUATION (on unseen test data)")
print("=" * 60)
print(f"Accuracy : {accuracy:.2%}   (overall % of correct predictions)")
print(f"Precision: {precision:.2%}   (of predicted approvals, % actually correct)")
print(f"Recall   : {recall:.2%}   (of true approvals, % the model caught)")
print(f"F1 Score : {f1:.2%}   (balance of precision & recall)")
print(f"ROC-AUC  : {roc_auc:.2%}   (how well model separates approved vs rejected)")
print("\nFull classification report:")
print(classification_report(y_test, y_pred, target_names=["Rejected", "Approved"]))

# -------------------------------------------------------------------
# STEP 6: SAVE VISUALS FOR THE DEMO / PRESENTATION
# -------------------------------------------------------------------
sns.set_style("whitegrid")

# 6a. Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["Rejected", "Approved"], yticklabels=["Rejected", "Approved"])
plt.title("Confusion Matrix")
plt.ylabel("Actual")
plt.xlabel("Predicted")
plt.tight_layout()
plt.savefig("confusion_matrix.png", dpi=150)
plt.close()

# 6b. Feature Importance
importances = pd.Series(model.feature_importances_, index=X.columns).sort_values(ascending=True)
plt.figure(figsize=(7, 5))
importances.plot(kind="barh", color="#4C72B0")
plt.title("Which Factors Matter Most for Loan Approval?")
plt.xlabel("Importance Score")
plt.tight_layout()
plt.savefig("feature_importance.png", dpi=150)
plt.close()

# 6c. ROC Curve
fpr, tpr, _ = roc_curve(y_test, y_proba)
plt.figure(figsize=(5, 4))
plt.plot(fpr, tpr, label=f"Random Forest (AUC = {roc_auc:.2f})", color="#4C72B0")
plt.plot([0, 1], [0, 1], "k--", label="Random Guess")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve")
plt.legend()
plt.tight_layout()
plt.savefig("roc_curve.png", dpi=150)
plt.close()

print("\n" + "=" * 60)
print("STEP 6: CHARTS SAVED")
print("=" * 60)
print("Saved: confusion_matrix.png, feature_importance.png, roc_curve.png")

# -------------------------------------------------------------------
# STEP 7: SAVE THE TRAINED MODEL (so it can be reused without retraining)
# -------------------------------------------------------------------
joblib.dump(model, "loan_rf_model.joblib")
joblib.dump(list(X.columns), "feature_columns.joblib")
print("\nModel saved as loan_rf_model.joblib")

# -------------------------------------------------------------------
# STEP 8: DEMO - PREDICT ON A NEW/SAMPLE APPLICANT (for live demo)
# -------------------------------------------------------------------
print("\n" + "=" * 60)
print("STEP 8: LIVE DEMO PREDICTION")
print("=" * 60)
sample_applicant = X_test.iloc[[0]]
prediction = model.predict(sample_applicant)[0]
probability = model.predict_proba(sample_applicant)[0][1]
print("Sample applicant data:")
print(sample_applicant.to_string(index=False))
print(f"\nPrediction: {'APPROVED' if prediction == 1 else 'REJECTED'}")
print(f"Model confidence (probability of approval): {probability:.1%}")

# Save a results summary to a text file too, for easy reference
with open("results_summary.txt", "w") as f:
    f.write("LOAN APPROVAL & RISK ASSESSMENT SYSTEM - RESULTS SUMMARY\n")
    f.write("=" * 60 + "\n")
    f.write(f"Model: Random Forest Classifier ({model.n_estimators} trees)\n")
    f.write(f"Dataset: {df.shape[0]} loan applications, {X.shape[1]} features\n")
    f.write(f"Train/Test Split: {len(X_train)} / {len(X_test)}\n\n")
    f.write(f"Accuracy : {accuracy:.2%}\n")
    f.write(f"Precision: {precision:.2%}\n")
    f.write(f"Recall   : {recall:.2%}\n")
    f.write(f"F1 Score : {f1:.2%}\n")
    f.write(f"ROC-AUC  : {roc_auc:.2%}\n\n")
    f.write("Top factors influencing approval (most to least important):\n")
    for feat, score in importances.sort_values(ascending=False).items():
        f.write(f"  - {feat}: {score:.3f}\n")

print("\nAll done. Results summary written to results_summary.txt")
